import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

_db = Path(os.getenv("DB_PATH", "data/app.db"))
DB_PATH = str(_db if _db.is_absolute() else BASE_DIR / _db)
MENU_PATH = BASE_DIR / "data" / "menu.json"
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-flash")
THINKING = os.getenv("DEEPSEEK_THINKING", "disabled")  # "disabled" | "enabled"

MAX_TOOL_ROUNDS = 6      # safety cap on tool-call iterations per user turn
HISTORY_LIMIT = 20       # prior user/assistant messages replayed within a conversation
