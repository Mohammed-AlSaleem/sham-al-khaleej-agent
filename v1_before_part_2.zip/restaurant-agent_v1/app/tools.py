"""Tools exposed to the LLM, plus server-side enforcement of hard constraints.

Design note: the model decides *what* to search for, but allergies and diets stored in
memory are applied here regardless of what the model passes. A forgotten constraint in
the prompt therefore cannot produce an unsafe recommendation.
"""
from . import memory, menu

CATEGORIES = menu.categories()

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_menu",
            "description": (
                "Search the restaurant menu. Returns real items with prices, ingredients, allergens and spice "
                "levels. The guest's stored allergies/diets are applied automatically. Call with no arguments "
                "to list everything."),
            "parameters": {
                "type": "object",
                "properties": {
                    "category": {"type": "string", "enum": CATEGORIES},
                    "diet": {"type": "array", "items": {"type": "string", "enum": sorted(menu.DIET_RULES)},
                             "description": "Diets the dish must satisfy."},
                    "exclude_allergens": {"type": "array", "items": {"type": "string", "enum": menu.allergen_vocab()}},
                    "exclude_ingredients": {"type": "array", "items": {"type": "string"},
                                            "description": "Ingredients to avoid, e.g. 'eggplant', 'chicken'."},
                    "max_price": {"type": "number"}, "min_price": {"type": "number"},
                    "max_spice": {"type": "integer", "minimum": 0, "maximum": 3},
                    "min_spice": {"type": "integer", "minimum": 0, "maximum": 3},
                    "tags": {"type": "array", "items": {"type": "string"},
                             "description": "e.g. high-protein, light, hearty, shareable, seafood."},
                    "query": {"type": "string", "description": "Keywords matched against name, description, ingredients, tags."},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_item",
            "description": "Get full details of one menu item by id, including any conflict with the guest's hard constraints.",
            "parameters": {"type": "object", "properties": {"item_id": {"type": "string"}}, "required": ["item_id"]},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "update_memory",
            "description": (
                "Save, change or remove a durable fact about the guest. Use op='set' for new facts AND for "
                "corrections (it replaces the previous fact for the same subject). Use op='remove' when the guest "
                "drops a preference entirely. kinds: diet (subject e.g. vegetarian|vegan|pescatarian|gluten-free|"
                "dairy-free), allergen (subject from the menu allergen list or a common word like peanuts/shrimp), "
                "ingredient, dish (subject = menu item id), category, spice (subject 'tolerance', "
                "value {'max_level': 0-3}), budget (subject 'max_item_price' or 'max_total', value {'amount': N}), other."),
            "parameters": {
                "type": "object",
                "properties": {
                    "op": {"type": "string", "enum": ["set", "remove"]},
                    "kind": {"type": "string", "enum": list(memory.KINDS)},
                    "subject": {"type": "string"},
                    "polarity": {"type": "string", "enum": list(memory.POLARITIES),
                                 "description": "like / avoid / limit (limit for spice and budget). Ignored for diet and allergen."},
                    "strength": {"type": "string", "enum": ["hard", "soft"],
                                 "description": "hard = must never be violated (e.g. 'I can't eat X'); soft = taste."},
                    "value": {"type": "object"},
                    "note": {"type": "string", "description": "The guest's own words, short."},
                },
                "required": ["op", "kind", "subject"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "record_order",
            "description": "Record the order once the guest has confirmed what they want. Items violating hard constraints are rejected.",
            "parameters": {
                "type": "object",
                "properties": {"items": {"type": "array", "items": {
                    "type": "object",
                    "properties": {"item_id": {"type": "string"}, "quantity": {"type": "integer", "minimum": 1}},
                    "required": ["item_id"]}}},
                "required": ["items"],
            },
        },
    },
]


# ---------------------------------------------------------------- constraint helpers
def hard_constraints(prefs: list[dict]) -> dict:
    return {
        "diets": sorted({p["subject"] for p in prefs if p["kind"] == "diet" and p["subject"] in menu.DIET_RULES}),
        "allergens": sorted({p["subject"] for p in prefs if p["kind"] == "allergen"}),
        "ingredients": sorted({p["subject"] for p in prefs
                               if p["kind"] == "ingredient" and p["polarity"] == "avoid" and p["strength"] == "hard"}),
    }


def item_conflicts(item: dict, prefs: list[dict]) -> list[str]:
    hc = hard_constraints(prefs)
    out = []
    out += [f"contains {a}" for a in hc["allergens"] if a in item["allergens"]]
    out += [f"not {d}" for d in hc["diets"] if not menu.DIET_RULES[d](item)]
    out += [f"contains {s}" for s in hc["ingredients"] if any(s in ing.lower() for ing in item["ingredients"])]
    return out


def _compact(i: dict) -> dict:
    return {k: i[k] for k in ("id", "name", "category", "price", "spice_level", "vegetarian", "vegan",
                              "description", "ingredients", "allergens", "tags")}


# ---------------------------------------------------------------- dispatcher
def execute_tool(name: str, args: dict, ctx: dict) -> dict:
    """ctx: user_id, conversation_id, source_message_id, memory_events (list, mutated)."""
    uid = ctx["user_id"]

    if name == "search_menu":
        prefs = memory.get_active_preferences(uid)
        hc = hard_constraints(prefs)
        diets = args.get("diet") or []
        bad = [d for d in diets if d not in menu.DIET_RULES]
        if bad:
            return {"error": f"unknown diet {bad}; allowed: {sorted(menu.DIET_RULES)}"}
        base = dict(category=args.get("category"), exclude_allergens=args.get("exclude_allergens") or [],
                    exclude_ingredients=args.get("exclude_ingredients") or [], max_price=args.get("max_price"),
                    min_price=args.get("min_price"), max_spice=args.get("max_spice"), min_spice=args.get("min_spice"),
                    tags=args.get("tags") or [], query=args.get("query"))
        requested = menu.search_items(diets=diets, **base)
        final_args = dict(base)
        final_args["exclude_allergens"] = sorted(set(base["exclude_allergens"]) | set(hc["allergens"]))
        final_args["exclude_ingredients"] = sorted(set(base["exclude_ingredients"]) | set(hc["ingredients"]))
        final = menu.search_items(diets=sorted(set(diets) | set(hc["diets"])), **final_args)
        kept = {i["id"] for i in final}
        return {"count": len(final), "items": [_compact(i) for i in final],
                "hard_constraints_applied": hc,
                "hidden_by_hard_constraints": [i["name"] for i in requested if i["id"] not in kept]}

    if name == "get_item":
        item = menu.get_item(args.get("item_id", ""))
        if not item:
            return {"error": "unknown item_id"}
        return {"item": _compact(item), "conflicts_with_guest_constraints": item_conflicts(item, memory.get_active_preferences(uid))}

    if name == "update_memory":
        op, kind, subject = args.get("op"), args.get("kind"), (args.get("subject") or "").strip()
        if not subject or kind not in memory.KINDS:
            return {"error": f"kind must be one of {list(memory.KINDS)} and subject is required"}
        subjects = [subject.lower()]
        if kind == "allergen":
            mapped = menu.normalize_allergen(subject)
            if not mapped:
                return {"error": f"'{subject}' is not in the menu allergen list {menu.allergen_vocab()}. "
                                 f"Store it with kind='ingredient', polarity='avoid', strength='hard' instead."}
            subjects = mapped
        if kind == "diet" and subjects[0] not in menu.DIET_RULES:
            return {"error": f"unknown diet; supported: {sorted(menu.DIET_RULES)}. Use kind='other' for anything else."}
        if kind == "dish" and not menu.get_item(subjects[0]):
            return {"error": "for kind='dish' the subject must be a menu item id (use search_menu to find it)"}
        results = []
        for s in subjects:
            if op == "remove":
                results.append(memory.remove_preference(uid, kind, s))
            else:
                results.append(memory.set_preference(
                    uid, kind, s, args.get("polarity") or "like", args.get("strength") or "soft",
                    args.get("value"), args.get("note"), ctx.get("source_message_id")))
        ctx.setdefault("memory_events", []).extend(results)
        return {"results": results}

    if name == "record_order":
        prefs = memory.get_active_preferences(uid)
        lines, total, problems = [], 0.0, []
        for entry in args.get("items") or []:
            item, qty = menu.get_item(entry.get("item_id", "")), int(entry.get("quantity") or 1)
            if not item:
                problems.append(f"unknown item {entry.get('item_id')}")
                continue
            conflicts = item_conflicts(item, prefs)
            if conflicts:
                problems.append(f"{item['name']} conflicts with guest constraints ({', '.join(conflicts)})")
                continue
            lines.append((item["id"], qty))
            total += item["price"] * qty
        if problems or not lines:
            return {"error": "order not recorded", "problems": problems or ["no items"]}
        oid = memory.record_order(uid, ctx.get("conversation_id"), lines, total)
        return {"order_id": oid, "total_sar": total, "items": [{"item_id": i, "quantity": q} for i, q in lines]}

    return {"error": f"unknown tool {name}"}
