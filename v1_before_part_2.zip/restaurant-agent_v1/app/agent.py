"""Agent loop: DeepSeek (OpenAI-compatible) with tool calling, grounded in the menu and long-term memory."""
import json
import logging

from . import config, memory, menu
from .tools import TOOLS, execute_tool

log = logging.getLogger("agent")
_client = None

SYSTEM_PROMPT = """You are the ordering assistant for Sham Al-Khaleej, a Levantine & Gulf restaurant. You help guests decide what to order.

How to behave
- Talk naturally. Learn tastes (favourite foods, diet, allergies, dislikes, spice tolerance, budget) through conversation, never as a questionnaire. Ask at most one short question at a time, and only when the answer would change your recommendation.
- Every dish, price, ingredient, allergen or spice level you mention MUST come from tool results (search_menu / get_item). Never invent or recall menu details from memory. If nothing matches, say so and offer the closest real alternative from the tool results.
- Save durable facts the guest states with update_memory as soon as they are stated, without asking permission. Do not save one-off requests for this meal only ("something light tonight") unless they sound like a lasting preference.
- If the guest corrects or changes something ("actually I eat fish now", "I can handle spicy food now"), call update_memory with op='set' for the new fact (it replaces the old one), or op='remove' if they drop it. The latest statement always beats stored memory.
- Allergies and diets are hard constraints: never recommend a dish that violates them. For allergies, remind the guest to tell the kitchen about cross-contact.
- Use the guest memory below to personalise. Mention it only when it changes the recommendation, and never ask again for something you already know. Returning guests should feel recognised, not interrogated.
- Prices are in SAR. Keep replies short, warm and concrete: usually 2-3 dishes, one line on why each fits, with price.
- Reply in the language the guest writes in (Arabic or English).
- When the guest decides, confirm items and total, then call record_order.
- Never mention tools, databases or memory mechanics."""


def get_client():
    global _client
    if _client is None:
        from openai import OpenAI
        _client = OpenAI(api_key=config.DEEPSEEK_API_KEY, base_url=config.DEEPSEEK_BASE_URL, timeout=60)
    return _client


def build_system_prompt(user: dict, prefs: list[dict]) -> str:
    recent = memory.get_recent_order_items(user["id"])
    names = [menu.get_item(i)["name"] for i in recent if menu.get_item(i)]
    parts = [SYSTEM_PROMPT, "", f"Guest: {user['username']} ({'returning' if user['is_returning'] else 'new'} guest)",
             "What you remember about this guest:", memory.format_memory_for_prompt(prefs)]
    if names:
        parts.append("Previously ordered: " + ", ".join(names))
    return "\n".join(parts)


def _llm_kwargs() -> dict:
    kw = {"extra_body": {"thinking": {"type": config.THINKING}}}
    if config.THINKING == "enabled":
        kw["reasoning_effort"] = "low"
    else:
        kw["temperature"] = 0.3
    return kw


def run_turn(user: dict, conversation_id: str, user_message: str) -> dict:
    history = memory.get_history(conversation_id)
    source_id = memory.log_message(conversation_id, "user", user_message)
    prefs = memory.get_active_preferences(user["id"])
    messages = [{"role": "system", "content": build_system_prompt(user, prefs)}, *history,
                {"role": "user", "content": user_message}]
    ctx = {"user_id": user["id"], "conversation_id": conversation_id,
           "source_message_id": source_id, "memory_events": []}
    tool_trace, final = [], None

    for _ in range(config.MAX_TOOL_ROUNDS):
        resp = get_client().chat.completions.create(
            model=config.DEEPSEEK_MODEL, messages=messages, tools=TOOLS, **_llm_kwargs())
        msg = resp.choices[0].message
        entry = {"role": "assistant", "content": msg.content or ""}
        # DeepSeek thinking mode + tools: reasoning_content must be sent back on later requests (else HTTP 400).
        reasoning = getattr(msg, "reasoning_content", None)
        if reasoning is not None:
            entry["reasoning_content"] = reasoning
        if not msg.tool_calls:
            final = msg.content or ""
            break
        entry["tool_calls"] = [{"id": tc.id, "type": "function",
                                "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                               for tc in msg.tool_calls]
        messages.append(entry)
        for tc in msg.tool_calls:
            try:
                args = json.loads(tc.function.arguments or "{}")
                result = execute_tool(tc.function.name, args, ctx)
            except Exception as e:  # tool errors go back to the model so it can recover
                log.exception("tool %s failed", tc.function.name)
                args, result = {}, {"error": f"{type(e).__name__}: {e}"}
            tool_trace.append({"tool": tc.function.name, "args": args})
            messages.append({"role": "tool", "tool_call_id": tc.id,
                             "content": json.dumps(result, ensure_ascii=False)})

    if final is None:
        final = "Sorry, I got tangled up there. Could you say that again?"
    memory.log_message(conversation_id, "assistant", final)
    return {"reply": final, "memory_events": ctx["memory_events"], "tool_trace": tool_trace}
